from mqtt.simple import MQTTClient
from machine import Pin
import ubinascii
import machine
import micropython


#定义输出端口为GPIO5,即NodeMCU-v1.0开发板上的D1
BeepPin = Pin(5, Pin.OUT, value=1)

#MQTT服务端信息，使用时修改成自己的
SERVER = "183.230.40.39"   #ONENET服务器地址
SERVER_PORT=6002           #ONENET服务器端口
CLIENT_ID = "3784858"      #创建设备时得到的设备ID，为数字字串
TOPIC = b"zhimadiyled"     #订阅的topic
username='74321'           #注册产品时，平台分配的产品ID，为数字字串
password='zhimadiymicropythonesp8266' #鉴权信息


state = 0

def sub_cb(topic, msg):
    global state
    print((topic, msg))
    if msg == b"on":
        BeepPin.value(0)
        state = 1
    elif msg == b"off":
        BeepPin.value(1)
        state = 0

def main(server=SERVER):
    #括号里主要是客户端ID，服务器地址，服务器端口，用户产品ID，鉴权信息
    c = MQTTClient(CLIENT_ID, server,6002,username,password)
    # Subscribed messages will be delivered to this callback
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(TOPIC)
    print("Connected to %s, subscribed to %s topic" % (server, TOPIC))

    try:
        while 1:
            #micropython.mem_info()
            c.wait_msg()
    finally:
        c.disconnect()

main()