import time
import ubinascii
import machine
from umqtt.robust import MQTTClient
from dht import DHT11
from machine import Pin

#MQTT服务端信息，使用时修改成自己的
SERVER = "183.230.40.39"   #ONENET服务器地址
SERVER_PORT=6002           #ONENET服务器端口
CLIENT_ID = "3784858"      #创建设备时得到的设备ID，为数字字串
TOPIC = b"$dp"             #ONENET上传数据点需要传到此TOPIC
username='74321'           #注册产品时，平台分配的产品ID，为数字字串
password='zhimadiymicropythonesp8266'  #鉴权信息

#设置GPIO5为按钮输入端口
door_switch = Pin(5, Pin.IN)
# ESP8266 ESP-12 有一个低电平触发，连接在GPIO2端口上的LED
led = Pin(2, Pin.OUT, value=1)


def pack_msg(message):
    msglen=len(message)
    tmp=[0,0,0]
    tmp[0]='\x03'
    tmp[1]=msglen>>8
    tmp[2]=msglen&0XFF
    message="%c%c%c%s"%(tmp[0],tmp[1],tmp[2],message)    #将消息封装为ONENET要求的格式
    return message


def main(server=SERVER):
    c = MQTTClient(CLIENT_ID, server,SERVER_PORT,username,password)
    c.connect()
    print("Connected to %s, uploading button status" % server)
    while True:
        while True:
            if door_switch.value()==0:
                msg="{\"notice\":0}"
                led.value(1)
            else:
                msg="{\"notice\":1}"  
                led.value(0)       
            msg=pack_msg(msg)
            print(msg)
            c.publish(TOPIC, msg)
            time.sleep_ms(2000)

    c.disconnect()

main()