import time
import ubinascii
import machine
from umqtt.robust import MQTTClient
from dht import DHT11
from machine import Pin

#MQTT服务端信息，使用时修改成自己的
SERVER = "183.230.40.39"   #ONENET服务器地址
SERVER_PORT=6002           #ONENET服务器端口
CLIENT_ID = "3784858"      #创建设备时得到的设备ID，为数字字串
TOPIC = b"$dp"             #ONENET上传数据点需要传到此TOPIC
username='74321'           #注册产品时，平台分配的产品ID，为数字字串
password='zhimadiymicropythonesp8266'  #鉴权信息


def pack_msg(message):
    msglen=len(message)
    tmp=[0,0,0]
    tmp[0]='\x03'
    tmp[1]=msglen>>8
    tmp[2]=msglen&0XFF
    message="%c%c%c%s"%(tmp[0],tmp[1],tmp[2],message)    #将消息封装为ONENET要求的格式
    return message

ds=DHT11(Pin(5))
def read_dht():
    try:
        ds.measure()
        tem=ds.temperature()
        hum=ds.humidity()
        print("temperature is %d,humidity is %d"%(tem,hum))
        return (tem,hum)
    except Exception as e:
        return (-1,-1)

def main(server=SERVER):
    c = MQTTClient(CLIENT_ID, server,SERVER_PORT,username,password)
    c.connect()
    print("Connected to %s, uploading DHT11 data to server" % server)
    while True:
        while True:
            (tem,hum) = read_dht()
            time.sleep_ms(2000)
            msg="{\"temperature\":%d,\"humidity\":%d}"%(tem,hum)
            msg=pack_msg(msg)
            print(msg)
            c.publish(TOPIC, msg)
            time.sleep_ms(2000)

    c.disconnect()

main()